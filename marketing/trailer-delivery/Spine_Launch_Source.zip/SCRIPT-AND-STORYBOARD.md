# Spine launch film — production script and storyboard

80 seconds · 30 fps · 2400 frames. All scene intervals are half open.

The locked master timeline
The master is 80 seconds and 2400 frames. Final displayed frame: 2399. Scene instructions use local seconds from each scene's start. Exact copy is provided in the scene pages. Do not remove a section to reach a shorter marketing convention.
Scene
Seconds
Frames
Main source and event
01
0 to 6
0 to 179
Illustrated scattered work
02
6 to 10
180 to 299
01 and welcome
03
10 to 22
300 to 659
02 and 03 question and answer
04
22 to 28
660 to 839
04 shared answer suggested
05
28 to 35
840 to 1049
05 idea receives approval
06
35 to 44
1050 to 1319
06 teammate joins
07
44 to 51
1320 to 1529
07 next step gains an owner
08
51 to 61
1530 to 1829
08 to 10 blocker and recovery
09
61 to 66
1830 to 1979
11 project goes Live
10
66 to 75
1980 to 2249
12 to 14 report and verification
11
75 to 80
2250 to 2399
Logo and invitation
Fixed priorities
Help Desk is a human assistance story. Ideas & Projects is a separate initiative story. Pulse is a visible intervention. The outcome is useful work with a reported saving checked outside the team. Do not flatten these into a chatbot tour.
The main film has no future integration montage. Its last fifteen seconds belong to the product outcome and invitation. The separate teaser is specified on page 13 and preserves the user's interest in Teams, Slack and Claude.
Production milestones
First assemble the exact script and eleven static storyboard frames. Then render an animatic with rough sound and all reading holds. Then polish motion, add final audio and produce the variants. Do not build variants while the master still contains defects. The storyboard is a progress deliverable, not a stopping point or an automatic approval gate.



Scenes 01 and 02 opening and welcome
Scene 01  Company wide fragmentation
Time: 0 to 6 seconds. Headline: “AI is everywhere.” Then: “Progress can get lost.”
Paper background. Three miniature desks at x 360, 960 and 1560, with centre height around y 650. Priya has a question, Mia has a useful answer and Louie has a project note. Three readable category tags: “Questions”, “Know how”, “Ideas”. These are editorial props, not fake screenshots of Teams. Each desk has one disconnected cobalt stroke.
Local 0.0 to 0.2: desks settle by 20 px; the first headline is already readable. Local 0.2 to 2.7: hold. Priya looks towards a question card. Mia has useful knowledge on her monitor. Louie has an idea nobody else can see. Local 2.7 to 3.0: headline changes. Local 3.0 to 5.7: hold “Progress can get lost.” The strokes extend slightly but do not meet. Local 5.7 to 6.0: they move towards centre to set up the welcome.
Do not use “Most AI ideas quietly die” as a factual claim. The supplied brief proposes that line but provides no evidence for “most”. The chosen line states the recognisable risk without inventing a prevalence statistic. Keep the mood curious rather than alarmist. No exploding inbox or employees looking incompetent.
Scene 02  A warm arrival
Time: 6 to 10 seconds. Headline: “Welcome to Spine.” Subline: “Your company's AI adoption, together.”
Cobalt background, paper type. The three strokes resolve into the Spine mark at the top centre, then crossfade to the genuine brand asset. Hold the headline and subline from local 0.3 to 3.7. An enlarged crop from clip 01, “3 things need you”, occupies the lower third as supporting proof of a calm starting point. Keep the irrelevant tasks outside the crop.
The logo transformation completes by 0.3. A warm chord lands with it. The characters glance up towards the new shared space. Use one understated accent behind the logo, not confetti over the copy. At local 3.7 to 4.0 the background returns to paper and the line moves towards Priya's desk.
Pass condition: the viewer knows the name and the company wide purpose before the Help Desk starts. “3 things need you” is readable but does not compete with the welcome. If the lower crop crowds the composition, remove it rather than reducing the main type. The source remains useful as the visual reference.

Scenes 03 and 04 help that spreads
Scene 03  A question only the company can answer
Time: 10 to 22 seconds. Headline: “Your question. Your company's answer.” Sources: clips 02 and 03; clip 15 is reference only.
Exact question: “Can I put client contract data into Copilot?” Enlarged editorial answer summary: “Use the company Claude workspace. Replace client names first.” Label this panel “Mia's answer · Summary”. It is a summary, not a replacement falsely painted into the original message. A small “Company demo guidance” label keeps the rule specific to this fictional employer.
Local 0.0 to 0.5: establish Priya's desk on the left and Mia's separate desk on the right. The centre shows the completed question crop from clip 02. Local 0.5 to 4.5: hold the full question. Local 4.5 to 5.5: cut to Mia claiming the question in clip 03. The cobalt line reaches her monitor. Local 5.5 to 6.0: reveal the completed reply and the enlarged summary. Local 6.0 to 11.7: hold. Priya relaxes and returns to work. Local 11.7 to 12.0: transition.
The source answer says Copilot is approved for internal data only until Legal signs off, recommends the company Claude workspace and replacing client names, and refers to the Playbook. Do not generalise this into advice about Copilot or Claude outside the fictional company. Do not show the full paragraph in tiny text and expect it to be read.
Scene 04  The next person benefits
Time: 22 to 28 seconds. Headline: “Once shared, one answer goes further.” Source: clip 04.
Local 0.0 to 0.5: a separate shared answer symbol enters with the headline. Keep the previous private thread locked and off stage. Local 0.5 to 1.5: show Ben's near duplicate question and the real “Already answered?” suggestion appearing. Remove the long typing section. Local 1.5 to 5.7: hold the suggestion at readable size. Ben's portrait turns towards it. Local 5.7 to 6.0: clear the screen for the initiative chapter.
Do not claim the recording shows Ben reading the full answer if it only shows the suggestion. The visible payoff is that relevant prior knowledge is surfaced before he sends another question. The phrase “Once shared” bridges the unrecorded sharing step honestly. No invented consent button or automatic publication animation.
Pass condition: human help and reusable knowledge are both clear. The story does not imply that a private client data question is automatically exposed to everyone.

Scenes 05 and 06 the collaboration centrepiece
Scene 05  A useful idea gets a start
Time: 28 to 35 seconds. Headline: “Give a good idea a way forward.” Source: clip 05.
Keep the project title “Supplier Research Assistant” throughout. Editorial problem summary: “Supplier research is scattered across websites and documents.” The recording contains a more detailed problem description; this shorter line belongs above the crop as a summary.
Local 0.0 to 0.5: show Louie's idea and the “Ideas & Projects” editorial chapter label. The product navigation itself says Initiatives and must remain unchanged. Local 0.5 to 4.5: hold the project title and problem. Local 4.5 to 5.0: show the real Approve action. Local 5.0 to 7.0: hold the resulting Forming team state, which continues into the next scene. Crop out the empty suggested plan and the auto approval timer. Never show an AI scorecard.
Scene 06  Someone chooses to join
Time: 35 to 44 seconds. Headline: “Your idea. Our next project.” Source: clip 06.
Begin on the same project in Forming team. Louie is at a desk to the left. Jamie is at another desk on the right browsing the real team view. The central source crop includes “Join the team” and the count. Use portrait labels “Louie · Owner” and “Jamie · Member”. Never show Alex as a member.
Local 0.0 to 1.0: establish one of three people and the join control. Local 1.0 to 2.0: show Jamie's real click and the count becoming two of three. Local 2.0 to 3.2: the two desk spaces slide together around an expanding project card. A round shared table appears underneath it. The camera pulls back by at most eight percent. Local 3.2 to 8.7: hold the headline, project and membership state. Louie places a source document on the table. Jamie places a workflow symbol beside it. Leave a third seat open, matching the recorded recruitment state. Local 8.7 to 9.0: the work surface becomes the plan crop.
This is the emotional centrepiece. We have seen separate workspaces; now the useful project has brought people together through a choice in Spine. The table is an editorial illustration of collaboration, not an in product meeting room. Do not invent a third join or imply AI assigned anyone.
Build with reusable SVG groups, arm rotation and translated desk layers. Crossfade a rounded rectangle into an ellipse rather than attempting a fragile complex morph. Keep the title on a separate stationary layer. Three avatars appearing under a caption would not demonstrate joining and is not an acceptable substitute.

Scenes 07 and 08 ownership and momentum
Scene 07  The next action is clear
Time: 44 to 51 seconds. Headline: “Everyone knows the next step.” Source: clip 07.
Exact next action: “Jamie is building the research template”. Use the source wording. Do not replace it with Alex testing examples from the earlier draft. The plan starts with Louie completing “List the supplier sources Procurement trusts”. The subsequent build step has Jamie's initials. Keep these relationships intact.
Local 0.0 to 0.5: the collaboration surface resolves into the plan. Local 0.5 to 1.5: show the recorded first step completion. Local 1.5 to 6.7: hold the updated next action and owner at readable size. A small source label indicates that the first draft came from AI; do not make that a second reading task. Local 6.7 to 7.0: cut to the check in.
Show no more than two plan rows at once. The full plan remains available as context in the source but is not readable at trailer scale. Do not fake all steps completing in seconds. The edit moves across project stages.
Scene 08  A real blocker reaches a person
Time: 51 to 61 seconds. Headline: “Keep good ideas moving.” Sources: clips 08, 09 and 10.
Editorial blocker summary: “Blocked: waiting for the SAP supplier list.” Recovery summary: “SAP export received. Back on track.” The exact longer source text remains in the underlying clips; place short summaries outside the footage and label them as summaries when needed.
Local 0.0 to 0.4: show the recorded Blocked check in selection with the complete note, skipping typing. Local 0.4 to 3.0: hold the blocker summary. Local 3.0 to 3.5: match cut the project into Pulse's top blocked item. Local 3.5 to 6.0: hold the Pulse item while the leader opens it. Local 6.0 to 6.5: cut to the completed recovery check in from clip 10 and its posted result. Local 6.5 to 10.0: hold the recovery summary and the cleared blocker state.
Do not fake a direct SAP integration or show Spine obtaining the export. Alex gets it through a human action outside the shown product. Do not invent an on screen upload action. Do not claim Pulse automatically solved or assigned the blocker. It made the issue visible and a person helped.
Pass condition: viewers see blocked work, Pulse making it visible and a recorded human recovery. A notification alone is not a complete story. Preserve the exact source order.

Scenes 09 and 10 delivered and verified
Scene 09  The project reaches use
Time: 61 to 66 seconds. Headline: “From idea to something the team uses.” Source: clip 11.
Local 0.0 to 0.5: crop tightly to “You're launching this” and Mark Live. Local 0.5 to 1.0: show the real click. Local 1.0 to 5.0: hold the project title with the green Live state. The cobalt connector completes its route. Louie and Jamie give one small pleased reaction. Use one soft resolved sound.
Do not invent a supplier comparison output or pretend Spine itself built the research tool. The available evidence demonstrates the initiative's launch status. The next scene provides the use and outcome evidence. Keep the completed plan rows collapsed if they would become a dense unreadable list.
Scene 10  Reporting becomes evidence
Time: 66 to 75 seconds. Headline: “See what it delivered.” Sources: clips 12, 13 and 14. Persistent disclosure: “Acme Group · Demo data”.
Local 0.0 to 0.4: reveal the completed report from clip 12. Local 0.4 to 3.0: hold an enlarged editorial equation, “18 × 40 min = 12 hours”. Label the factors “Requests” and “Minutes saved each” as secondary context. Keep it inside a clearly identified demo result area. A small status says “Reported”. The equation is derived from the actual demo report, not invented evidence.
Local 3.0 to 3.5: cut to the real Verify action in clip 13. Local 3.5 to 6.5: hold “12 hours saved” and “Verified by someone outside the team”. Keep the actual “Verified by Alex Morgan” attribution visible in the source crop if readable. Alex's portrait remains outside the project group. Never call this independent external verification.
Local 6.5 to 9.0: reveal the Leadership screen's Supplier Research Assistant entry under Went live, with the verified result still held as a foreground editorial highlight. This final source reveal is context, not a second dashboard reading task. Crop out the wider 106 total so it cannot be mistaken for the project's result. Keep the headline and disclosure still.
The number must not count up from zero as if it were accumulating live. The result becomes verified only after the Verify action. A checkmark appearing before verification would undermine the story. The warm musical resolution lands on verification, then leaves space for the closing invitation.
Pass condition: viewers understand a team reported a measured saving and someone outside that team checked it. They do not leave thinking 12 hours is a real customer testimonial or that this project saved 106 hours.

Scene 11 the final invitation
The closing composition
Time: 75 to 80 seconds. Hero: “Good ideas deserve to go somewhere.” Descriptor: “Spine · Run your company's AI adoption.” CTA: “Book a demo”.
Cobalt background. Real logo centred around y 220. Hero at y 390 in 88 px across two lines. Descriptor at y 650 in 56 px. CTA at y 790 in 56 px. Keep all text within the safe width. The characters may sit as a small group in a lower corner, but they must not compete with the product name or CTA.
Local 0.0 to 0.4: the cobalt route resolves into the logo arrangement and crossfades to the real asset. Local 0.4 to 5.0: hold every line absolutely still. The music resolves naturally. No fade to black before the last frame and no last second surprise text.
Use a verified demo destination only if supplied. Do not bake “your-url-here”, an invented domain or a non functional QR code into the exported film. If no URL is available, the clean “Book a demo” CTA is sufficient for a post carrying the link. Document the missing destination in delivery notes without stopping the build.
Copy hierarchy
The headline gives the meaning. The enlarged product crop proves an action. Narration connects the scenes. Captions reproduce narration. Disclosure labels qualify demo data. If those compete, remove secondary labels or shorten narration; do not reduce the core text.
Avoid vague replacements such as “Unlock your potential”, “The future of work” or “Seamless collaboration”. The concrete result is that the company can help people, form projects and see delivered value. Keep British English. Do not add a paragraph under every headline.
What the new film must not inherit
No low resolution review video as source. No old public website captures. No private AI scores. No loading plan. No switching between Supplier Risk Checker and Supplier Research Assistant. No generic standing mascot next to each screenshot. No pretend SAP connector. No incorrect team membership. No unbuilt integrations presented as current. No unsupported adoption percentage or invented customer endorsement.
The welcome and collaboration transformation provide the fun. The clear interventions and verified result provide the product's credibility. Both must be visible in the final film; one cannot substitute for the other.

Narration music and caption script
Exact narration by scene
Use a warm, conversational British English voice. Speak with curiosity and confidence, not an exaggerated sales voice. Leave pauses. Generate or record each scene separately so it fits without rushing.
01: “AI is everywhere at work. But good questions and ideas can get lost.”
02: “Welcome to Spine.”
03: “Ask the question only your company can answer. A Champion helps you move forward.”
04: “Once shared, that answer helps the next person too.”
05: “Give a useful idea a place to start and a decision that moves it forward.”
06: “Find the people who want to build it with you.”
07: “A clear plan. A named owner. Everyone knows the next step.”
08: “When work gets blocked, Pulse brings it to someone's attention, so the team can move again.”
09: “Take it live and put it to work.”
10: “Report what it saved. Have someone outside the team verify it. Give leadership a clear view.”
11: “Spine. Run your company's AI adoption.”
Keep each line at least 0.25 seconds from its scene boundary. Narration must not describe an action before the viewer sees it. Never speed speech more than five percent to fit. If needed, shorten a line and note the edit. All main messages must remain understandable muted.
Sound direction
One properly licensed or original instrumental track, about 105 to 115 BPM. Warm electronic percussion, restrained bass and playful plucked notes. Add a warm chord lift at the welcome, fuller texture at joining and a brief reduction at the blocker. Resolve at verification and close with a natural musical ending. Do not shorten reading holds to hit every beat.
Use a small selection click, a soft teammate arrival and a Live confirmation. Do not make every card whoosh. Avoid corporate ukulele, alarm sounds, epic trailer drums and frantic dance drops. Keep a provenance and permitted use record for all audio.
Mix and access
Target approximately -16 LUFS integrated with true peak at or below -1 dBTP. Duck music beneath speech and check on a phone speaker. Captions: maximum two lines, 52 px type with 56 px line spacing, within y 940 to 1060. Use a dark backing when contrast needs it. Export a clean master, a captioned master and an SRT aligned to the actual voice.
If authorised voice generation is unavailable, continue the visual build and supply the timed script. Clearly identify the missing voice layer; do not describe an incomplete audio build as fully finished. Never use a celebrity imitation or unlicensed commercial song.



## Production note
Voice generation is unavailable. Exact narration is retained as a timed recording script; exports use an original instrumental score. Storyboard PNGs are in output/storyboard. Source mappings are in src/shots.json.
