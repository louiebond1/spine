# Source mapping
All sources were retrieved from the Spine `spine-2/marketing` URLs in spec/assets.json. Original footage is retained unchanged. Each crop's native rectangle, first source frame, and frame count are specified in src/shots.json. scripts/prepare.py extracts exactly those source frames with FFmpeg. Every advancing frame is 1:1 at 30 fps; the last frame is held, never accelerated. SourceCrop bounds frame indexes deterministically.

| Master frames | Source crop | Treatment |
|---|---|---|
|180–299|home|Completed-state freeze|
|300–434|question|Posted question freeze|
|435–464|claim|24 normal-speed source frames + 6-frame action hold|
|465–659|reply|Sent reply freeze, separate labelled summary|
|660–839|suggestion|Completed suggestion, no invented read or sharing click|
|840–974|idea|Recorded title and editorial problem summary|
|975–989|approve|10 normal-speed source frames + 5-frame action hold|
|990–1049|forming|Completed Forming team freeze|
|1050–1079|one|One of three before joining|
|1080–1109|join|26 normal-speed source frames + 4-frame action hold|
|1110–1319|two|Two of three after joining|
|1320–1364|plan|15 frame before hold + 30 normal-speed frames|
|1365–1529|next|Updated next action|
|1530–1619|blocked|Posted blocker and labelled summary|
|1620–1709|pulse|Top blocked initiative; Open crop over last 25 frames|
|1710–1724|recover|10 normal-speed source frames + 5-frame action hold|
|1725–1829|recovered|Posted On track recovery note|
|1830–1859|launch|15 frame before hold + 15 normal-speed frames|
|1860–1979|live|Green Live state|
|1980–2069|report|Posted report and derived demo equation|
|2070–2084|verify|15 source frames, normal speed|
|2085–2174|verified|Verified attribution|
|2175–2249|leadership|Went live row; wider 106 metric excluded|
|2250–2399|logo|Genuine logo crop from supplied screenshot|

The final logo uses a direct crop of 01-home-what-needs-you.png, not reconstructed text. No standalone brand vector was linked. Larger UI quotations remain outside recorded imagery. Illustrations are editorial metaphors, not product controls.
