from pathlib import Path
from PIL import Image,ImageDraw
import subprocess
for n,a,b in [(3,5,8),(5,7,8.8),(6,4.3,5.7),(7,7,9),(8,14,16),(10,11,13.2),(11,4.2,5.6),(13,7.5,9.3)]:
 p=next(Path('public/assets').glob(f'{n:02}-*.mp4')); ts=[a+(b-a)*i/7 for i in range(8)]; sh=Image.new('RGB',(1600,8*245),'#ddd'); dr=ImageDraw.Draw(sh)
 for i,t in enumerate(ts):
  out=f'/tmp/action-{n}-{i}.jpg'; subprocess.run(['ffmpeg','-v','error','-ss',str(t),'-i',str(p),'-vf','crop=2280:950:540:180,scale=800:-1','-frames:v','1','-y',out],check=True)
  im=Image.open(out); im.thumbnail((800,220)); sh.paste(im,(0,i*245+25));dr.text((5,i*245+5),f'{n:02} {t:.3f}',fill='black')
 sh.save(f'output/inspection/actions-{n:02}.jpg')
