from pathlib import Path
import json
# Timed recording/caption script. No claim of alignment to a recorded voice.
cues=[(.3,2.8,'AI is everywhere at work.'),(3,5.7,'But good questions and ideas can get lost.'),(6.4,9.7,'Welcome to Spine.'),(10.5,14.4,'Ask the question only your company can answer.'),(16,21.7,'A Champion helps you move forward.'),(22.4,27.7,'Once shared, that answer helps the next person too.'),(28.4,32.4,'Give a useful idea a place to start'),(32.6,34.7,'and a decision that moves it forward.'),(35.4,43.7,'Find the people who want to build it with you.'),(44.3,47.5,'A clear plan. A named owner.'),(47.6,50.7,'Everyone knows the next step.'),(51.3,54,'When work gets blocked,'),(54.1,57,'Pulse brings it to someone’s attention,'),(57.5,60.7,'so the team can move again.'),(61.3,65.7,'Take it live and put it to work.'),(66.3,68.9,'Report what it saved.'),(69.5,72.4,'Have someone outside the team verify it.'),(72.5,74.7,'Give leadership a clear view.'),(75.4,79.7,'Spine. Run your company’s AI adoption.')]
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
Path('output/Spine_Launch_Timed_Script.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(a)} --> {stamp(b)}\n{text}' for i,(a,b,text) in enumerate(cues))+'\n')
Path('src/captions.json').write_text(json.dumps(cues,indent=2))
