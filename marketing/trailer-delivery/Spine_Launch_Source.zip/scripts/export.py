import subprocess,json
from pathlib import Path

def run(args):subprocess.run(args,check=True)
# Patch files are rendered from the same final source. Unaffected frames are reused.
patches=[(171,300),(435,1830),(2250,2400)]
args=['ffmpeg','-v','error','-i','output/Master-silent.mp4']
for start,end in patches:args+=['-i',f'output/patch-{start}.mp4']
args+=['-i','public/assets/audio/master.wav']
filters=[];labels=[];cursor=0
for i,(start,end) in enumerate(patches):
 if cursor<start:
  lab=f'base{i}';filters.append(f'[0:v]trim=start_frame={cursor}:end_frame={start},setpts=PTS-STARTPTS[{lab}]');labels.append(f'[{lab}]')
 labels.append(f'[{i+1}:v]');cursor=end
filters.append(''.join(labels)+f'concat=n={len(labels)}:v=1:a=0[v]')
args+=['-filter_complex',';'.join(filters),'-map','[v]','-map','4:a','-c:v','libx264','-crf','18','-preset','fast','-pix_fmt','yuv420p','-r','30','-c:a','aac','-b:a','192k','-t','80','-movflags','+faststart','-y','output/Spine_Launch_Master_1080p.mp4']
if all(Path(f'output/patch-{start}.mp4').exists() for start,end in patches):run(args)
else:run(['ffmpeg','-v','error','-i','output/Master-silent.mp4','-i','public/assets/audio/master.wav','-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-b:a','192k','-t','80','-movflags','+faststart','-y','output/Spine_Launch_Master_1080p.mp4'])
run(['ffmpeg','-v','error','-i','output/Spine_Launch_Master_1080p.mp4','-vf',"subtitles=output/Spine_Launch_Timed_Script.srt:fontsdir=public/assets/fonts:force_style='FontName=DejaVu Sans,FontSize=14,PrimaryColour=&H00EAF2F5,OutlineColour=&H003A2414,BorderStyle=3,Outline=2,Shadow=0,Alignment=2,MarginV=6'",'-c:v','libx264','-crf','18','-preset','fast','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart','-y','output/Spine_Launch_Captioned_1080p.mp4'])
for sec,name in [(7.5,'Welcome'),(40,'Together'),(71,'Verified')]:
 run(['ffmpeg','-v','error','-ss',str(sec),'-i','output/Spine_Launch_Master_1080p.mp4','-frames:v','1','-y',f'output/Spine_Still_{name}.png'])
