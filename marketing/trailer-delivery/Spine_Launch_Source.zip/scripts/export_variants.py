import subprocess
from pathlib import Path
for ident,name,seconds in [('Vertical','Spine_Launch_Vertical_1080x1920',80),('Short','Spine_Launch_15s',15),('Future','Spine_Coming_Next_18s',18)]:
 # Dedicated musical ending: early score section crossfades into the composed final chord.
 if seconds==80:af='[1:a]anull[a]'
 else:af=f'[1:a]atrim=0:{seconds-3},asetpts=PTS-STARTPTS[first];[1:a]atrim=75:79,asetpts=PTS-STARTPTS[last];[first][last]acrossfade=d=1[a]'
 subprocess.run(['ffmpeg','-v','error','-i',f'output/{ident}-silent.mp4','-i','public/assets/audio/master.wav','-filter_complex',af,'-map','0:v','-map','[a]','-c:v','copy','-c:a','aac','-b:a','192k','-t',str(seconds),'-movflags','+faststart','-y',f'output/{name}.mp4'],check=True)
