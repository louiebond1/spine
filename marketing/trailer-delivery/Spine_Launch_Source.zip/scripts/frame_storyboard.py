import csv,json
from pathlib import Path
shots={s['id']:s for s in json.loads(Path('src/shots.json').read_text())}
starts=[0,180,300,660,840,1050,1320,1530,1830,1980,2250,2400]
def choose(s,f):
 if s==0 or s==10:return '',0
 if s==1:return 'home',0
 if s==2:return ('question',0) if f<135 else ('claim',f-135) if f<165 else ('reply',0)
 if s==3:return 'suggestion',0
 if s==4:return ('idea',0) if f<135 else ('approve',f-135) if f<150 else ('forming',0)
 if s==5:return ('one',0) if f<30 else ('join',f-30) if f<60 else ('two',0)
 if s==6:return ('plan',max(0,f-15)) if f<45 else ('next',0)
 if s==7:return ('blocked',0) if f<90 else ('pulse',0) if f<155 else ('open',f-155) if f<180 else ('recover',f-180) if f<195 else ('recovered',0)
 if s==8:return ('launch',max(0,f-15)) if f<30 else ('live',0)
 return ('report',0) if f<90 else ('verify',f-90) if f<105 else ('verified',0) if f<195 else ('leadership',0)
with open('FRAME-BY-FRAME-STORYBOARD.csv','w') as file:
 w=csv.writer(file);w.writerow(['output_frame','seconds','scene','local_frame','crop_id','source_file','source_frame','treatment'])
 for g in range(2400):
  s=next(i for i in range(11) if starts[i]<=g<starts[i+1]);f=g-starts[s];key,sf=choose(s,f)
  if key:
   shot=shots[key];index=min(shot['frames']-1,max(0,sf));w.writerow([g,f'{g/30:.6f}',s+1,f,key,shot['source'],shot['sourceStartFrame']+index,'freeze' if shot['frames']==1 or sf>=shot['frames'] else 'normal speed'])
  else:w.writerow([g,f'{g/30:.6f}',s+1,f,'illustration','','','frame-derived vector animation'])
