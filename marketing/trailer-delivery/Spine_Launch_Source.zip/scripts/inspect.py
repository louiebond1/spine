from PIL import Image,ImageDraw
from pathlib import Path
import subprocess,json
assets=Path('public/assets'); out=Path('output/inspection')
for p in sorted(assets.glob('*.mp4')):
 d=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(p)]))
 times=[0,d*.25,d*.5,d*.75,max(0,d-.15)]
 sheet=Image.new('RGB',(1440,5*430),'#dedede'); draw=ImageDraw.Draw(sheet)
 for i,t in enumerate(times):
  f=out/f'{p.stem}-{i}.jpg'; subprocess.run(['ffmpeg','-v','error','-ss',str(t),'-i',str(p),'-frames:v','1','-q:v','2','-y',str(f)],check=True)
  im=Image.open(f); im.thumbnail((1440,405)); sheet.paste(im,(0,i*430+25)); draw.text((10,i*430+5),f'{p.name} | {t:.2f}s',fill='black')
 sheet.save(out/f'{p.stem}-sheet.jpg')
for page in range(3):
 ps=sorted(assets.glob('*.png'))[page*6:(page+1)*6]; sheet=Image.new('RGB',(1800,1800),'#ddd'); draw=ImageDraw.Draw(sheet)
 for i,p in enumerate(ps):
  im=Image.open(p); im.thumbnail((890,560)); x=(i%2)*900;y=(i//2)*600;sheet.paste(im,(x,y+30));draw.text((x,y+5),p.name,fill='black')
 sheet.save(out/f'screens-{page}.jpg')
