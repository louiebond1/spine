import numpy as np,wave
from pathlib import Path
SR=48000;D=80;mix=np.zeros((SR*D,2),dtype=np.float64);rng=np.random.default_rng(17)
def note(at,dur,freq,amp,kind='pluck',pan=0):
 n=int(SR*dur);t=np.arange(n)/SR
 if kind=='pluck': signal=(np.sin(2*np.pi*freq*t)+.28*np.sin(2*np.pi*freq*2*t))*np.exp(-t*5)*np.minimum(t/.008,1)
 elif kind=='pad':signal=(np.sin(2*np.pi*freq*t)+.2*np.sin(2*np.pi*freq*1.003*t))*np.minimum(t/.35,1)*np.minimum((dur-t)/.65,1)
 elif kind=='kick':signal=np.sin(2*np.pi*(46*t+35*.025*(1-np.exp(-t/.025))))*np.exp(-t*17)
 else:signal=rng.normal(0,1,n)*np.exp(-t*65)*.3
 a=int(at*SR);b=min(len(mix),a+n)
 if b<=a:return
 gain=.35 if 51<=at<57 else 1
 signal=signal[:b-a]*amp*gain
 mix[a:b,0]+=signal*np.sqrt((1-pan)/2);mix[a:b,1]+=signal*np.sqrt((1+pan)/2)
beat=60/110
chords=[[146.83,220,293.66,369.99],[130.81,196,261.63,329.63],[164.81,246.94,329.63,392],[110,164.81,220,277.18]]
for bar in range(35):
 at=bar*4*beat
 if at>75:break
 chord=chords[bar%4]
 for freq in chord:note(at,4*beat+.25,freq,.055,'pad')
 for k in range(4):
  t=at+k*beat
  note(t,.3,52,.14,'kick');note(t+beat*.5,.07,1,.07,'hat',.25)
  note(t,1,chord[k%4]*2,.11,'pluck',(-.35 if k%2 else .35))
  if 35<=t<51:note(t+beat*.5,.65,chord[(k+1)%4]*4,.04,'pluck',-.4)
for at in [6,37,69.5,75]:
 for freq in [146.83,220,293.66,369.99,440]:note(at,4.7 if at==75 else 2.2,freq,.065,'pad')
for at in [14.8,32.9,36.6,45.2,57.3,61.8,69.4]:note(at,.12,740,.055,'pluck')
fade=np.minimum(np.arange(SR*D)/SR/.05,1)*np.minimum((SR*D-np.arange(SR*D))/SR/1.5,1);mix*=fade[:,None]
mix=np.tanh(mix)*.8
p=Path('public/assets/audio');p.mkdir(exist_ok=True)
with wave.open(str(p/'original-score.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((mix*32767).astype('<i2').tobytes())
