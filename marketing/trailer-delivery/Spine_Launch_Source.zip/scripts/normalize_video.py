from pathlib import Path
import subprocess,json
for p in Path('output').glob('Spine_*.mp4'):
 info=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=pix_fmt,color_range','-of','json',str(p)]))['streams'][0]
 if info.get('pix_fmt')=='yuv420p' and info.get('color_range')!='pc':continue
 dest=p.with_name(p.stem+'-limited.mp4')
 subprocess.run(['ffmpeg','-v','error','-i',str(p),'-vf','scale=in_range=pc:out_range=tv,format=yuv420p','-color_range','tv','-c:v','libx264','-crf','18','-preset','fast','-c:a','copy','-movflags','+faststart','-y',str(dest)],check=True)
 dest.replace(p);print('NORMALIZED',p.name)
