from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path('.');out=Path('output/Spine_Launch_Source.zip')
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for folder in ['src','scripts','public','spec']:
  for p in (root/folder).rglob('*'):
   if p.is_file():z.write(p,str(p))
 for name in ['package.json','package-lock.json','tsconfig.json','README.md','SCRIPT-AND-STORYBOARD.md','SOURCE-MAPPING.md','FRAME-BY-FRAME-STORYBOARD.csv','Spine_Launch_QA.md']:
  z.write(name,name)
 for p in Path('output/storyboard').glob('*.png'):z.write(p,str(p))
 for p in Path('output').glob('*.srt'):z.write(p,str(p))
 for p in Path('output/qa').glob('*.json'):z.write(p,str(p))
print(out,out.stat().st_size)
