from pathlib import Path
import subprocess,json,concurrent.futures
# Native pixel crops, normal-speed action windows, verified final-frame freezes.
rows=[
('home',1,4,1,[550,210,900,120]),
('question',2,23.3,1,[550,235,1100,180]),
('claim',3,6.5,24,[1880,600,260,140]),
('reply',3,19.43,1,[630,670,1500,220]),
('suggestion',4,12.5,1,[850,365,1150,255]),
('idea',5,6,1,[550,235,1100,112]),
('approve',5,7.7,10,[2220,815,560,95]),
('forming',5,8.7,1,[550,380,1040,160]),
('one',6,3.5,1,[590,675,740,210]),
('join',6,4.1,26,[2510,660,280,120]),
('two',6,5.7,1,[590,675,740,270]),
('plan',7,7.2,30,[600,745,1100,170]),
('next',7,10,1,[550,470,850,100]),
('blocked',8,16.4,1,[550,460,1300,120]),
('pulse',9,5,1,[590,450,1100,240]),
('open',9,8,25,[2590,535,210,120]),
('recover',10,12.05,10,[2540,1290,250,110]),
('recovered',10,13.2,1,[590,1130,1100,130]),
('launch',11,4.4,15,[2520,450,280,120]),
('live',11,5.4,1,[550,470,300,90]),
('report',12,13.8,1,[590,1300,1330,160]),
('verify',13,8.3,15,[2580,820,210,125]),
('verified',13,9.3,1,[590,820,1350,130]),
('leadership',14,10,1,[590,1180,1100,240]),
]
def work(row):
 key,num,start,count,crop=row; p=next(Path('public/assets').glob(f'{num:02}-*.mp4')); out=Path('public/assets/frames')/key;out.mkdir(parents=True,exist_ok=True)
 x,y,w,h=crop
 subprocess.run(['ffmpeg','-v','error','-ss',str(round(start*30)/30),'-i',str(p),'-vf',f'crop={w}:{h}:{x}:{y}','-frames:v',str(count),'-q:v','1','-start_number','0','-y',str(out/'%03d.jpg')],check=True)
 return {'id':key,'source':p.name,'sourceStartFrame':round(start*30),'frames':count,'crop':crop,'playback':'normal speed' if count>1 else 'verified freeze'}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: result=list(pool.map(work,rows))
Path('src/shots.json').write_text(json.dumps(result,indent=2))
