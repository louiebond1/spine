from pathlib import Path
import subprocess,json
rows=[]
for p in sorted(Path('output').glob('Spine_*.mp4')):
 info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(p)]))
 video=next(s for s in info['streams'] if s['codec_type']=='video');audio=next(s for s in info['streams'] if s['codec_type']=='audio')
 row={'file':p.name,'width':video['width'],'height':video['height'],'fps':video['r_frame_rate'],'frames':video['nb_read_frames'],'duration':info['format']['duration'],'video':video['codec_name'],'pixel_format':video['pix_fmt'],'audio':audio['codec_name']}
 expected=450 if '15s' in p.name else 540 if '18s' in p.name else 2400
 assert int(row['frames'])==expected,row
 assert row['fps']=='30/1' and row['video']=='h264' and row['audio']=='aac' and row['pixel_format']=='yuv420p',row
 subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],check=True)
 row['full_decode']='passed';rows.append(row);print(json.dumps(row))
Path('output/qa/technical-results.json').write_text(json.dumps(rows,indent=2))
