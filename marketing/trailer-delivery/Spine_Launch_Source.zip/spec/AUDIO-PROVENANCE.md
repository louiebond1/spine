# Audio provenance
Original procedural score composed for this project by scripts/music.py. 110 BPM, deterministic seed 17. All oscillators, envelopes and percussion are generated mathematically; no sampled songs, commercial recordings, or external sound libraries. May be used and edited with this trailer. Mastered using FFmpeg loudnorm to -16 LUFS target, -1 dBTP limit.

No voice generation tool is available. No synthetic or recorded voice is included. The narrated script and timing files are preparation for recording, not a claim of an existing voice performance. Captions in the captioned version are timed script text, not transcriptions of audio. Phone-speaker listening and actual normal-speed audiovisual playback require a human review.
