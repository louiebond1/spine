from pathlib import Path
import numpy as np,soundfile as sf,json
from scipy.signal import butter,sosfilt,resample_poly
R=Path(__file__).resolve().parents[1];sr=48000;duration=80;N=sr*duration;rng=np.random.default_rng(540)
music=np.zeros((N,2));voice=np.zeros(N);sfx=np.zeros((N,2));beat=60/110

def add(buf,a,t,vol=1,pan=0):
 i=round(t*sr);n=min(len(a),len(buf)-i)
 if n<=0:return
 if buf.ndim==1:buf[i:i+n]+=a[:n]*vol
 else:buf[i:i+n,0]+=a[:n]*vol*np.sqrt((1-pan)/2);buf[i:i+n,1]+=a[:n]*vol*np.sqrt((1+pan)/2)
def tone(midi,length,kind='pluck'):
 t=np.arange(round(length*sr))/sr;hz=440*2**((midi-69)/12)
 if kind=='pad':
  a=(np.sin(2*np.pi*hz*t)+.2*np.sin(2*np.pi*hz*2*t)+.15*np.sin(2*np.pi*hz*.998*t))*np.minimum(1,t/.25)*np.minimum(1,(length-t)/.6)*.5
 elif kind=='bass':a=(np.sin(2*np.pi*hz*t)+.18*np.sin(2*np.pi*hz*2*t))*np.minimum(1,t/.015)*np.exp(-t*3)
 else:a=(np.sin(2*np.pi*hz*t)+.3*np.sin(2*np.pi*hz*2.002*t)+.07*np.sin(2*np.pi*hz*3*t))*np.minimum(1,t/.004)*np.exp(-t*5)
 return a
chords=[[50,57,61,66],[47,54,59,62],[43,50,57,59],[45,52,59,61]]
for bar in range(36):
 t=bar*4*beat;ch=chords[bar%4]
 if t>=76:break
 strength=.65 if t<6 else 1.0
 if 51<=t<57:strength=.35
 for n in ch:add(music,tone(n+12,4*beat+.3,'pad'),t,.055*strength,pan=(n%3-1)*.35)
 for b,n in [(0,ch[0]),(1.5,ch[1]),(3,ch[0]+12)]:add(music,tone(n-12,.7,'bass'),t+b*beat,.17*strength)
 for step,n in enumerate([ch[2]+12,ch[3]+12,ch[1]+24,ch[2]+12]):
  pt=t+(step+.5)*beat;add(music,tone(n,1),pt,.075*strength,pan=(-.35 if step%2 else .35));add(music,tone(n,1),pt+beat*.75,.018*strength,pan=.5)
 for b in range(4):
  tt=np.arange(int(sr*.19))/sr;kick=np.sin(2*np.pi*(48*tt+45*.028*(1-np.exp(-tt/.028))))*np.exp(-tt*24)
  if b in (0,2):add(music,kick,t+b*beat,.16*strength)
  if b in (1,3):
   noise=rng.normal(0,1,len(tt));a=sosfilt(butter(2,[800,5000],fs=sr,btype='band',output='sos'),noise)*np.exp(-tt*45);add(music,a,t+b*beat,.065*strength,.1)
 for b in range(8):
  tt=np.arange(int(sr*.055))/sr;a=sosfilt(butter(2,7000,fs=sr,btype='high',output='sos'),rng.normal(0,1,len(tt)))*np.exp(-tt*85);add(music,a,t+b*.5*beat,.021*strength,(-1)**b*.35)
# Deliberate harmonic arrival / joining / verification; natural final decay.
for t,notes,v in [(6,[62,66,69,73],.10),(37,[62,66,69,74],.06),(69.5,[62,66,69,73],.11),(75,[50,62,66,69,74],.10)]:
 for n in notes:add(music,tone(n,4.8,'pad'),t,v)
for t,notes in [(14.7,[81]),(32.7,[81]),(36.7,[74,81]),(45.2,[81]),(57.3,[79]),(61.8,[74,78,81]),(69.4,[74,78,81])]:
 for j,n in enumerate(notes):add(sfx,tone(n,.5),t+j*.065,.07)
phrases=json.loads((R/'src/narration.json').read_text());duck=np.ones(N)
for p in phrases:
 a,fs=sf.read(R/'public/assets/audio'/p['file']);a=resample_poly(a,sr,fs);a=a/(max(np.max(abs(a)),.001))*.62;add(voice,a,p['start']);i=int(max(0,p['start']-.14)*sr);end=int(min(duration,p['end']+.25)*sr);duck[i:end]=.24
# Smooth ducking, no pumping.
k=np.ones(int(sr*.09))/(sr*.09);duck=np.convolve(duck[::48],np.ones(90)/90,mode='same');duck=np.repeat(duck,48)[:N]
sf.write(R/'public/assets/audio/instrumental.wav',music,sr,subtype='PCM_24');music*=duck[:,None];fade=np.minimum(1,np.arange(N)/sr/.12)*np.minimum(1,(N-np.arange(N))/sr/1.0);mix=music+voice[:,None]+sfx;mix*=fade[:,None]
sf.write(R/'public/assets/audio/mix-raw.wav',mix,sr,subtype='PCM_24');sf.write(R/'public/assets/audio/music.wav',music,sr,subtype='PCM_24')
def tc(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
srt=[]
for i,p in enumerate(phrases):
 words=p['text'].split();lines=[];cur=''
 for word in words:
  if len(cur)+len(word)>48:lines.append(cur);cur=word
  else:cur+=((' ' if cur else '')+word)
 lines.append(cur);srt.append(f"{i+1}\n{tc(p['start'])} --> {tc(p['end'])}\n"+'\n'.join(lines)+'\n')
(R/'output/Spine_Launch_Timed_Script.srt').write_text('\n'.join(srt));print('Original 110 BPM score, narration and sound effects mixed.')
