from pathlib import Path
import json,textwrap
R=Path(__file__).resolve().parents[1];phrases=json.loads((R/'src/narration.json').read_text())
def tc(t,ass=False):
 ms=round(t*(100 if ass else 1000));unit=100 if ass else 1000
 return (f'{ms//(3600*unit)}:{ms//(60*unit)%60:02}:{ms//unit%60:02}.{ms%unit:02}' if ass else f'{ms//(3600*unit):02}:{ms//(60*unit)%60:02}:{ms//unit%60:02},{ms%unit:03}')
for vertical in [False,True]:
 width,height=(1080,1920) if vertical else (1920,1080);name='Vertical' if vertical else 'Master';events=[];srt=[];index=0
 for p in phrases:
  chunks=textwrap.wrap(p['text'],width=52 if vertical else 100,break_long_words=False);total=sum(len(c.split()) for c in chunks);elapsed=0
  for c in chunks:
   n=len(c.split());start=p['start']+(p['end']-p['start'])*elapsed/total;end=p['start']+(p['end']-p['start'])*(elapsed+n)/total;elapsed+=n;lines=textwrap.wrap(c,width=27 if vertical else 48,break_long_words=False);assert len(lines)<=2,(c,lines)
   index+=1;srt.append(f'{index}\n{tc(start)} --> {tc(end)}\n'+ '\n'.join(lines)+'\n');events.append(f'Dialogue: 0,{tc(start,True)},{tc(end,True)},Default,,0,0,0,,'+'\\N'.join(lines))
 ass=f'''[Script Info]\nScriptType: v4.00+\nPlayResX: {width}\nPlayResY: {height}\nWrapStyle: 2\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Default,Inter,52,&H00FFFFFF,&H00FFFFFF,&H003A2414,&H003A2414,0,0,0,0,100,100,0,0,3,9,0,2,{90 if vertical else 120},{150 if vertical else 120},{160 if vertical else 28},1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n'''+ '\n'.join(events)+'\n'
 (R/f'output/{name}.ass').write_text(ass);(R/f'output/Spine_Launch_{name}.srt').write_text('\n'.join(srt))
