from pathlib import Path
import json,re,csv
R=Path(__file__).resolve().parents[1];scenes=[(0,180,'Fragmented work','Three articulated colleagues use separate desks; disconnected cobalt strokes; headline changes at frame 81.'),(180,120,'Welcome','Strokes resolve into the authentic app mark; company purpose; cobalt field.'),(300,360,'Company-specific help','Question holds 15–134; actual Claim 135–161; completed answer and labelled summary from 165.'),(660,180,'Shared knowledge','Editorial privacy bridge; Ben receives the real Already answered suggestion. No invented sharing action.'),(840,210,'Idea approval','One Supplier Research Assistant idea, problem summary; recorded human Approve 135–153; forming-team evidence from 154.'),(1050,270,'Voluntary collaboration','One of three; real Join 30–55; two of three from 56; two articulated people bring desks to a common table during 60–95; third seat open.'),(1320,210,'Owned plan','Recorded first-step completion 15–44; updated Jamie next action from 45. AI drafts, people own work.'),(1530,300,'Blocker, Pulse, recovery','Blocked check-in summary 0–89; actual Pulse item90–154; Open155–179; human recovery submission180–194; posted On track check-in195–299.'),(1830,150,'Live','Actual Mark Live8–29; actual green Live state30–149. No invented research-tool output.'),(1980,270,'Reported and verified','Reported equation0–89; actual Verify90–104; verified12hours105–194; Leadership Went live195–269. Persistent demo disclosure, Alex outside project.'),(2250,150,'Invitation','Genuine vector brand; stable hero, descriptor and Book a demo. No invented URL.')]
voice=json.loads((R/'src/narration.json').read_text());lines=['# Spine launch — rebuilt production script','', '80 seconds · 1920×1080 · 30fps · 2400 frames. Original final brief governs this production.','']
for i,(start,dur,title,action) in enumerate(scenes):
 lines += [f'## {i+1:02} · {title} · {start/30:g}–{(start+dur)/30:g}s', '',action,'']
 for v in voice:
  if start/30<=v['start']<(start+dur)/30:lines += [f"Narration {v['start']:.2f}–{v['end']:.2f}s: “{v['text']}”",'']
lines += ['No narration text was shortened. Kokoro British voice bf_emma; no celebrity imitation. Any generated speech rate adjustment is at most1.05×.','', 'Original score:110BPM, generated locally from deterministic synthesis; no sampled commercial music.','']
(R/'spec/FINAL-SCRIPT.md').write_text('\n'.join(lines))
(R/'spec/STORYBOARD.md').write_text('# Frame-accurate storyboard\n\n'+ '\n\n'.join(f'## {i+1:02} {title}\n\nFrames{start}–{start+dur-1}: {action}\n\n![Storyboard](../output/storyboard/{i+1:02}.png)' for i,(start,dur,title,action) in enumerate(scenes)))
with (R/'spec/frame-storyboard.csv').open('w') as out:
 w=csv.writer(out);w.writerow(['outputFrame','timeSeconds','scene','localFrame','direction'])
 for i,(start,dur,title,action) in enumerate(scenes):
  for f in range(start,start+dur):w.writerow([f,f/30,title,f-start,action])
