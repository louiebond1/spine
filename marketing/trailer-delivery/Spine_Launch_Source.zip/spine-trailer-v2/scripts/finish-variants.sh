#!/usr/bin/env bash
set -euo pipefail
export XDG_CACHE_HOME=/workspace/.cache
ffmpeg -y -v error -i output/Vertical-silent.mp4 -i public/assets/audio/final-mix.wav -map 0:v -map 1:a -vf "ass=output/Vertical.ass:fontsdir=public/assets/fonts" -c:v libx264 -threads 3 -preset fast -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart -t 80 output/Spine_Launch_Vertical_1080x1920.mp4
ffmpeg -y -v error -i public/assets/audio/instrumental.wav -filter_complex "[0:a]atrim=0:10,asetpts=PTS-STARTPTS[a];[0:a]atrim=75:80,asetpts=PTS-STARTPTS[b];[a][b]concat=n=2:v=0:a=1,afade=t=out:st=13.5:d=1.5,loudnorm=I=-16:TP=-2.5:LRA=9" -ar 48000 public/assets/audio/short.wav
ffmpeg -y -v error -i public/assets/audio/instrumental.wav -filter_complex "[0:a]atrim=0:13,asetpts=PTS-STARTPTS[a];[0:a]atrim=75:80,asetpts=PTS-STARTPTS[b];[a][b]concat=n=2:v=0:a=1,afade=t=out:st=16.5:d=1.5,loudnorm=I=-16:TP=-2.5:LRA=9" -ar 48000 public/assets/audio/future.wav
ffmpeg -y -v error -i output/Short-silent.mp4 -i public/assets/audio/short.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -movflags +faststart -t 15 output/Spine_Launch_15s.mp4
ffmpeg -y -v error -i output/Future-silent.mp4 -i public/assets/audio/future.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -movflags +faststart -t 18 output/Spine_Coming_Next_18s.mp4
