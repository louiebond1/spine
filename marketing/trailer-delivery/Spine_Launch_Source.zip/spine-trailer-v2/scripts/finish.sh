#!/usr/bin/env bash
set -euo pipefail
ffmpeg -y -v error -i output/Master-silent.mp4 -i public/assets/audio/final-mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -movflags +faststart -t 80 output/Spine_Launch_Master_1080p.mp4
ffmpeg -y -v error -i output/Spine_Launch_Master_1080p.mp4 -vf "ass=output/Master.ass:fontsdir=public/assets/fonts" -c:v libx264 -threads 3 -preset fast -crf 18 -pix_fmt yuv420p -c:a copy -movflags +faststart output/Spine_Launch_Captioned_1080p.mp4
ffmpeg -y -v error -ss 7.5 -i output/Spine_Launch_Master_1080p.mp4 -frames:v 1 output/Spine_Still_Welcome.png
ffmpeg -y -v error -ss 40 -i output/Spine_Launch_Master_1080p.mp4 -frames:v 1 output/Spine_Still_Together.png
ffmpeg -y -v error -ss 71.5 -i output/Spine_Launch_Master_1080p.mp4 -frames:v 1 output/Spine_Still_Verified.png
