from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
from pathlib import Path
R=Path(__file__).resolve().parents[1]; f=instantiateVariableFont(TTFont(R/'public/assets/fonts/Inter.ttf'),{'wght':600,'opsz':14}); gs=f.getGlyphSet();cmap=f.getBestCmap();up=f['head'].unitsPerEm;x=0;paths=[]
for c in 'Spine':
 g=gs[cmap[ord(c)]];p=SVGPathPen(gs);g.draw(p);paths.append(f'<path transform="translate({x} 0)" d="{p.getCommands()}"/>');x+=g.width-up*.02
for tone,color in [('light','#FFFFFF'),('dark','#14243A')]:
 # Exact app mark geometry, Inter 600 wordmark, app 18px mark /19px type/10px gap.
 svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="480" height="160" viewBox="0 0 96 32"><defs><linearGradient id="g" x2="0" y2="1"><stop stop-color="#81A0FF"/><stop offset="1" stop-color="#3B5BDB"/></linearGradient></defs><g transform="translate(0 4) scale(.5)"><rect x="9" y="2" width="24" height="10" rx="5" fill="url(#g)"/><rect x="2" y="20" width="32" height="10" rx="5" fill="url(#g)"/><rect x="0" y="38" width="20" height="10" rx="5" fill="url(#g)"/></g><g fill="{color}" transform="translate(28 23) scale({19/up} {-19/up})">{''.join(paths)}</g></svg>'''
 (R/f'public/assets/art/spine-{tone}.svg').write_text(svg)
