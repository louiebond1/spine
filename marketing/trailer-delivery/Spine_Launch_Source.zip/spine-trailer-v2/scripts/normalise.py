from pathlib import Path
import subprocess
R=Path(__file__).resolve().parents[1]
for p in sorted((R/'output').glob('Spine*.mp4')):
 tmp=p.with_suffix('.normalised.mp4')
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(p),'-map','0:v','-map','0:a','-vf','scale=out_range=tv:out_color_matrix=bt709,format=yuv420p,fps=30','-c:v','libx264','-threads','3','-preset','fast','-crf','18','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-r','30','-fps_mode','cfr','-video_track_timescale','15360','-c:a','copy','-movflags','+faststart',str(tmp)],check=True)
 tmp.replace(p);print('Normalised',p.name,flush=True)
