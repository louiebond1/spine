from pathlib import Path
import zipfile
R=Path(__file__).resolve().parents[1];dest=R/'output/Spine_Launch_Source.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in R.rglob('*'):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(R);parts=rel.parts
  if parts[0] in ['.venv','models','node_modules','.git','.npm-cache']:continue
  if parts[0]=='output' and not (parts[1]=='storyboard' or p.name=='Spine_Launch_QA.md' or p.suffix in ['.srt','.ass'] or (parts[1]=='review' and p.suffix in ['.json','.txt'])):continue
  if p.name in ['mix-raw.wav','music.wav']:continue
  z.write(p,Path('spine-trailer-v2')/rel)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 assert any(n.endswith('src/Root.tsx') for n in z.namelist())
 assert any(n.endswith('public/assets/audio/final-mix.wav') for n in z.namelist())
print(dest,dest.stat().st_size,'bytes; archive integrity passed')
