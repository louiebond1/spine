from pathlib import Path
import cv2,json,subprocess
R=Path(__file__).resolve().parents[1];D=R/'public/assets';(D/'focus').mkdir(exist_ok=True)
files={int(p.name[:2]):p for p in (D/'clips').glob('*.mp4')}
# Source frame, native crop. Every image is a real recorded frame; nothing repainted.
holds={
'home':(1,120,[550,210,900,120]),
'question':(2,699,[550,235,1100,130]),
'private':(3,235,[550,390,1300,70]),
'reply':(3,583,[630,635,1040,180]),
'suggestion':(4,310,[870,450,700,110]),
'idea':(5,180,[550,280,1150,65]),
'forming':(5,261,[550,380,1040,160]),
'one-count':(6,105,[590,675,300,75]),
 'two-count':(6,171,[590,675,300,75]),
 'one':(6,105,[590,675,740,210]),
'join-result':(6,171,[590,675,740,270]),
'next':(7,249,[550,470,850,100]),
'plan-result':(7,249,[590,765,1120,110]),
'blocked':(8,492,[590,1115,1220,150]),
'pulse':(9,60,[590,450,1100,240]),
'recovered':(10,396,[590,1130,1100,130]),
'live':(11,162,[550,470,300,90]),
'report':(12,414,[590,1300,1330,160]),
'verified':(13,279,[600,820,1350,130]),
'leadership':(14,300,[590,1180,1100,240])}
actions={
'claim':(3,195,27,[1870,605,280,100]),
'suggest-appear':(4,270,42,[870,450,700,110]),
'approve':(5,225,19,[2230,820,540,75]),
'join':(6,123,26,[2520,670,270,100]),
'complete':(7,216,30,[590,745,1120,155]),
'blocked-post':(8,432,60,[550,460,1320,120]),
'open':(9,237,25,[2600,545,190,90]),
'recover':(10,357,15,[2550,1300,240,90]),
'launch':(11,125,22,[2530,460,260,95]),
'verify':(13,240,23,[2580,830,205,100])}
manifest=[]
for name,(n,f,crop) in holds.items():
 cap=cv2.VideoCapture(str(files[n]));cap.set(0,0) if False else None;cap.set(cv2.CAP_PROP_POS_FRAMES,f);ok,im=cap.read();cap.release();assert ok,name
 x,y,w,h=crop;cv2.imwrite(str(D/'focus'/f'{name}.png'),im[y:y+h,x:x+w]);manifest.append(dict(id=name,source=files[n].name,startFrame=f,frames=1,crop=crop,kind='hold'))
for name,(n,f,count,crop) in actions.items():
 x,y,w,h=crop;w-=w%2;h-=h%2
 subprocess.run(['ffmpeg','-y','-v','error','-ss',str(f/30),'-i',str(files[n]),'-frames:v',str(count),'-vf',f'crop={w}:{h}:{x}:{y}','-an','-c:v','libx264','-crf','15','-pix_fmt','yuv420p',str(D/'focus'/f'{name}.mp4')],check=True)
 cap=cv2.VideoCapture(str(files[n]));cap.set(cv2.CAP_PROP_POS_FRAMES,f);ok,im=cap.read();cap.release();cv2.imwrite(str(D/'focus'/f'{name}-poster.png'),im[y:y+h,x:x+w])
 manifest.append(dict(id=name,source=files[n].name,startFrame=f,frames=count,crop=[x,y,w,h],kind='normal-speed action'))
(R/'spec/source-manifest.json').write_text(json.dumps(manifest,indent=2))
print('Prepared',len(manifest),'real footage crops')
