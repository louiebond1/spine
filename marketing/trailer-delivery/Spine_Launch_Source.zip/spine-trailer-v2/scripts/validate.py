from pathlib import Path
import json,subprocess
R=Path(__file__).resolve().parents[1];files={'Spine_Launch_Master_1080p.mp4':(1920,1080,2400),'Spine_Launch_Captioned_1080p.mp4':(1920,1080,2400),'Spine_Launch_Vertical_1080x1920.mp4':(1080,1920,2400),'Spine_Launch_15s.mp4':(1920,1080,450),'Spine_Coming_Next_18s.mp4':(1920,1080,540)};results={}
for name,(w,h,n) in files.items():
 p=R/'output'/name;data=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]));v=next(x for x in data['streams'] if x['codec_type']=='video');a=next(x for x in data['streams'] if x['codec_type']=='audio');assert(v['width'],v['height'],int(v['nb_frames']))==(w,h,n);assert v['r_frame_rate']=='30/1' and v['codec_name']=='h264' and v['pix_fmt']=='yuv420p';assert a['codec_name']=='aac';assert abs(float(v['duration'])-n/30)<0.001;buf=p.read_bytes();assert buf.index(b'moov')<buf.index(b'mdat');decode=subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],capture_output=True);assert decode.returncode==0 and not decode.stderr,decode.stderr
 results[name]={'width':w,'height':h,'frames':n,'fps':30,'seconds':float(v['duration']),'codec':'H.264/AAC','decode':'passed','fastStart':True};print(name,'PASS',flush=True)
(R/'output/review/technical-validation.json').write_text(json.dumps(results,indent=2))
