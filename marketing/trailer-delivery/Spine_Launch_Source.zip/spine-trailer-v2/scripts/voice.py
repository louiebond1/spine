import os,json
os.environ['OMP_NUM_THREADS']='2'
import onnxruntime as rt
from kokoro_onnx import Kokoro
import soundfile as sf
from pathlib import Path
root=Path(__file__).resolve().parents[1];os.chdir(root)
opts=rt.SessionOptions();opts.intra_op_num_threads=2;opts.inter_op_num_threads=1
k=Kokoro.from_session(rt.InferenceSession('models/kokoro-v1.0.onnx',sess_options=opts,providers=['CPUExecutionProvider']),'models/voices-v1.0.bin')
phrases=[(.3,2.7,'AI is everywhere at work.'),(2.95,5.75,'But good questions and ideas can get lost.'),(6.5,9.75,'Welcome to Spine.'),(10.6,15,'Ask the question only your company can answer.'),(16.2,21.75,'A Champion helps you move forward.'),(22.5,27.75,'Once shared, that answer helps the next person too.'),(28.3,34.75,'Give a useful idea a place to start and a decision that moves it forward.'),(37.4,43.75,'Find the people who want to build it with you.'),(44.3,47,'A clear plan. A named owner.'),(47.3,50.75,'Everyone knows the next step.'),(51.4,53.8,'When work gets blocked,'),(54.3,57.1,"Pulse brings it to someone's attention,"),(57.6,60.75,'so the team can move again.'),(62.2,65.75,'Take it live and put it to work.'),(66.4,68.8,'Report what it saved.'),(69.6,72.5,'Have someone outside the team verify it.'),(72.7,74.75,'Give leadership a clear view.'),(75.5,79.75,"Spine. Run your company's AI adoption.")]
results=[]
short={1:'But questions and ideas can get lost.',6:'Give an idea a place to start, and a decision that moves it forward.',15:'Someone outside the team verifies it.'}
for i,(start,end,text) in enumerate(phrases):
 a,sr=k.create(text,voice='bf_emma',speed=1.0,lang='en-gb'); original=text
 if len(a)/sr>end-start:
  a,sr=k.create(text,voice='bf_emma',speed=1.05,lang='en-gb')
 if len(a)/sr>end-start and i in short:
  text=short[i];a,sr=k.create(text,voice='bf_emma',speed=1.0,lang='en-gb')
 if len(a)/sr>end-start: print('OVERLONG',i,len(a)/sr,end-start,flush=True)
 sf.write(f'public/assets/audio/voice-{i:02}.wav',a,sr)
 results.append(dict(start=start,end=start+len(a)/sr,text=text,original=original,file=f'voice-{i:02}.wav'))
 print(i,round(len(a)/sr,2),text,flush=True)
Path('src/narration.json').write_text(json.dumps(results,indent=2))
