import React from 'react';
import {C,clamp} from '../design';
export type Person='Priya'|'Mia'|'Louie'|'Jamie'|'Alex'|'Ben';
const looks={Priya:[C.blue,'#B87550','#24283C'],Mia:[C.terra,'#E6AE8E','#633E2D'],Louie:[C.navy,'#DCA789','#423732'],Jamie:[C.green,'#E5B491','#252D35'],Alex:['#8B838D','#C68A64','#393B40'],Ben:['#8A92BC','#E5B491','#584634']};
// One articulated drawing per role; hands, eyes and shoulders move with narrative beats.
export function Character({person,f=0,mood='attentive',gesture=0,scale=1,flip=false}:{person:Person;f?:number;mood?:'neutral'|'attentive'|'pleased';gesture?:number;scale?:number;flip?:boolean}){
 const [shirt,skin,hair]=looks[person];const female=person==='Priya'||person==='Mia';
 const blink=(f%157>=150)?0.15:1;const nod=Math.sin(clamp(gesture)*Math.PI)*5;const hand=clamp(gesture)*26;
 return <svg width={300*scale} height={370*scale} viewBox="0 0 300 370" style={{overflow:'visible',transform:flip?'scaleX(-1)':undefined}}>
 <g stroke={C.navy} strokeWidth="3" strokeLinejoin="round" strokeLinecap="round">
 <path d="M87 262 Q77 311 105 346 L153 347 L165 292 L203 341 L246 339 L220 264" fill="#C2C6CF"/>
 <path d="M100 341 Q80 354 92 363 L154 363 L155 342M205 334 Q210 357 247 360 L265 359 Q270 348 242 335" fill={C.navy}/>
 <path d="M96 164 Q76 171 75 216 L84 279 Q145 295 215 272 L207 192 Q205 167 183 159" fill={shirt}/>
 <path d="M118 145 L117 174 Q143 198 168 173 L163 139" fill={skin}/>
 <path d="M118 166 Q140 187 166 164" fill="none" stroke="#FFFFFF" strokeOpacity=".25"/>
 <g transform={`rotate(${-nod} 145 140)`}>
 {female&&<path d="M100 57 Q76 80 84 137 L77 167 Q106 190 135 151 L178 163 Q205 142 183 75" fill={hair}/>}
 <path d="M104 76 Q120 52 161 65 Q189 75 184 105 L188 125 L178 129 Q171 158 142 159 Q107 151 104 117Z" fill={skin}/>
 <ellipse cx="104" cy="112" rx="10" ry="13" fill={skin}/>
 <path d="M100 108 Q87 75 112 56 Q148 36 179 60 Q193 71 186 95 Q162 94 152 72 Q135 93 111 94 L110 114" fill={hair}/>
 {person==='Mia'&&<circle cx="100" cy="61" r="23" fill={hair}/>}
 <path d="M133 102 L143 101 M164 100 L174 103" fill="none" stroke={hair}/>
 <ellipse cx={139+(mood==='attentive'?2:0)} cy="113" rx="3" ry={4*blink} fill={C.navy}/><ellipse cx="170" cy="113" rx="3" ry={4*blink} fill={C.navy}/>
 <path d="M156 112 L154 126 L160 127" fill="none" stroke="#A56F54" strokeWidth="2"/>
 <path d={mood==='pleased'?'M139 135 Q151 148 166 133':'M144 137 Q153 140 162 135'} fill={mood==='pleased'?'#FFF':'none'} strokeWidth="2"/>
 {person==='Louie'&&<path d="M123 133 Q142 160 169 139" fill="none" stroke={hair} strokeWidth="7" opacity=".6"/>}
 {person==='Priya'&&<circle cx="105" cy="129" r="5" fill="#D7BD79" stroke="none"/>}
 </g>
 <path d={`M94 182 Q74 206 94 237 L154 ${238-hand} L157 ${218-hand} L114 217 L117 192`} fill={shirt}/>
 <path d={`M153 ${220-hand} Q166 ${209-hand} 180 ${214-hand} L194 ${217-hand} Q199 ${222-hand} 189 ${224-hand} L174 ${224-hand} Q194 ${225-hand} 194 ${231-hand} L168 ${239-hand} L154 ${238-hand}Z`} fill={skin}/>
 <path d="M194 186 Q214 191 218 226 L245 233 L244 252 L205 249 Q183 234 180 214" fill={shirt}/>
 <path d="M244 233 Q262 229 272 236 L282 245 Q285 251 273 250 L258 247 L250 253 L240 251Z" fill={skin}/>
 <path d="M106 255 L110 269 M181 251 L185 269" stroke="#FFFFFF" strokeOpacity=".2"/>
 </g></svg>
}
export function Portrait({person,size=100,f=0}:{person:Person;size?:number;f?:number}){return <div style={{width:size,height:size,borderRadius:'50%',background:'#E8E5DE',overflow:'hidden',flexShrink:0}}><div style={{transform:`translate(${-size*.18}px,${-size*.3}px)`}}><Character person={person} f={f} scale={size/185}/></div></div>}
