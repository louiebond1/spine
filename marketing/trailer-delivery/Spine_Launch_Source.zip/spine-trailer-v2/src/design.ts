export const C={paper:'#F5F2EA',navy:'#14243A',blue:'#435CF5',green:'#248365',red:'#B7554B',terra:'#C97859',muted:'#6A716F'};
export const clamp=(x:number)=>Math.max(0,Math.min(1,x));
export const ease=(x:number)=>1-Math.pow(1-clamp(x),3);
export const enter=(f:number,start=0,duration=12)=>ease((f-start)/duration);
export const pos=(left:number,top:number,width?:number,height?:number):React.CSSProperties=>({position:'absolute',left,top,width,height});
