export const C={paper:'#F5F2EA',navy:'#14243A',blue:'#435CF5',white:'#FFFFFF',green:'#31866A',red:'#A55555',terracotta:'#B76D54'};
export const ease=(f:number,a=0,b=12)=>1-Math.pow(1-Math.max(0,Math.min(1,(f-a)/(b-a))),3);
export const safe={left:120,right:1800,top:96,bottom:910};
