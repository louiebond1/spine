export const timeline=[
{start:0,duration:180,title:'AI is everywhere.',voice:'AI is everywhere at work. But good questions and ideas can get lost.'},
{start:180,duration:120,title:'Welcome to Spine.',voice:'Welcome to Spine.'},
{start:300,duration:360,title:"Your question.\nYour company's answer.",voice:'Ask the question only your company can answer. A Champion helps you move forward.'},
{start:660,duration:180,title:'Once shared,\none answer goes further.',voice:'Once shared, that answer helps the next person too.'},
{start:840,duration:210,title:'Give a good idea\na way forward.',voice:'Give a useful idea a place to start and a decision that moves it forward.'},
{start:1050,duration:270,title:'Your idea.\nOur next project.',voice:'Find the people who want to build it with you.'},
{start:1320,duration:210,title:'Everyone knows\nthe next step.',voice:'A clear plan. A named owner. Everyone knows the next step.'},
{start:1530,duration:300,title:'Keep good ideas moving.',voice:"When work gets blocked, Pulse brings it to someone's attention, so the team can move again."},
{start:1830,duration:150,title:'From idea to something\nthe team uses.',voice:'Take it live and put it to work.'},
{start:1980,duration:270,title:'See what it delivered.',voice:'Report what it saved. Have someone outside the team verify it. Give leadership a clear view.'},
{start:2250,duration:150,title:'Good ideas deserve\nto go somewhere.',voice:"Spine. Run your company's AI adoption."}
];
